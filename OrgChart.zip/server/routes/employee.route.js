const express = require('express');
const asyncHandler = require('express-async-handler');
const employeeCtrl = require('../controllers/employee.controller');

const router = express.Router();
module.exports = router;

router.route('/').post(asyncHandler(insertEmployee));
router.route('/').get(asyncHandler(getEmployees));
router.route('/').put(asyncHandler(updateEmployees));
router.route('/:id').delete(asyncHandler(deleteEmployees));

async function insertEmployee(req, res) {
  console.log('inside post employee api');
  let employee = await employeeCtrl.insert(req.body);
  
  res.json(employee);
}

async function updateEmployees(req, res) {
  console.log('inside put employee api');
  try {
    await employeeCtrl.updateEmployee(req.body);
    res.send("Item Updated!");
  } catch (err) {
    console.error(err.message);
    res.send(400).send("Server Error");
  }
}


async function getEmployees(req,res){
  console.log('inside get employee api');
  let employee = await employeeCtrl.getEmployees();
  res.json(employee);
}

async function deleteEmployees(req, res) {
  try {
    await employeeCtrl.deleteEmployee(req.params.id);
    res.send("Item Deleted!");
  } catch (err) {
    console.error(err.message);
    res.send(400).send("Server Error");
  }
}
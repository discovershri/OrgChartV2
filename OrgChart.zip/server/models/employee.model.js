const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
  fullname: {
    type: String
  },
  pid: {
    type: String
  },
  nodeId:{
    type: String
  },
  title: {
    type: String
  },
  img: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  versionKey: false
});


module.exports = mongoose.model('Employee', EmployeeSchema);

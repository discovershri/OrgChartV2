
const Joi = require('joi');
const Employee = require('../models/employee.model');

const employeeSchema = Joi.object({
  id: Joi.string().required(),
  nodeId: Joi.string(),
  fullname: Joi.string(),
  pid: Joi.string(),
  title: Joi.string(),
  img: Joi.string(),
});


module.exports = {
  insert,
  getEmployees,
  updateEmployee,
  deleteEmployee
}

async function insert(employee) {
  user = await Joi.validate(employee, employeeSchema, { abortEarly: false });
  return await new Employee(employee).save();
}

async function getEmployees() {
  return await Employee.find({});
}

async function updateEmployee(employee) {
  return await Employee.findByIdAndUpdate(employee.id, {
    ...employee,
  });
}

async function deleteEmployee(id) {
  return await Employee.findOneAndDelete(id);
}

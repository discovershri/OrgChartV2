export interface Employee {
  nodeId: string;
  id: string;
  fullname: string;
  pid: string;
  title: string;
  img: string;
}

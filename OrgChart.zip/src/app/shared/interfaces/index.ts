export * from './user.interface';
export * from './employee.interface';

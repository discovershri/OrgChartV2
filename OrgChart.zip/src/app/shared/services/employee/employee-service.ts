import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { Employee } from "@app/shared/interfaces";
import { Observable, BehaviorSubject } from "rxjs";

interface EmpResponse {
  employee: Employee;
}

@Injectable({ providedIn: "root" })
export class EmployeeService {
  private employee$ = new BehaviorSubject<Employee | null>(null);
  constructor(private http: HttpClient) {}

  addEmployee(payload: Employee) {
    const {
      id,
      fullname = "Add name",
      pid,
      title = "Add title",
      img = "https://i.pravatar.cc/150?u=" + id,
    } = payload;
    const body = { id, nodeId: id, fullname, pid, title, img };
    return this.http.post("/api/employee", body);
  }

  getEmployees() {
    return this.http.get("/api/employee");
  }

  updateEmployee(payload: Employee) {
    return this.http.put("/api/employee/", payload);
  }

  deleteEmployee(id: string) {
    return this.http.delete("/api/employee/" + id);
  }
}

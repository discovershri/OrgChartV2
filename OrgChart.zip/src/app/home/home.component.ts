import { Component, OnInit } from "@angular/core";
import OrgChart from "@balkangraph/orgchart.js";
import { EmployeeService } from "@app/shared/services";
import * as mockJson from "./../../assets/mock.json";
import {  Router } from '@angular/router';

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"],
})
export class HomeComponent implements OnInit {
  constructor(private empService: EmployeeService, private router: Router) {}

  ngOnInit() {
    const that = this;
    const tree = document.getElementById("tree");
    if (tree) {
      var chart = new OrgChart(tree, {
        nodeBinding: {
          field_0: "name",
          field_1: "title",
          img_0: "img",
        },
        nodeMenu: {
          details: { text: "Details" },
          edit: { text: "Edit" },
          add: { text: "Add" },
          remove: { text: "Remove" },
        },
      });

      chart.on("update", function (sender: any, oldNode: any, newNode: any) {
        console.log("sender", sender);
        console.log("oldNode", oldNode);
        console.log("newNode", newNode);
        that.editEmployee(newNode);
        // sender.editUI.show(1);
      });

      chart.on("add", function (sender: any, node: any) {
        console.log("sender", sender);
        console.log("node", node);
        that.addEmployee(node);
        
        // sender.editUI.show(1);
      });

      chart.on("remove", function (sender: any, nodeId: any) {
        console.log("sender", sender);
        console.log("nodeId", nodeId);
        that.deleteEmployee(nodeId);
      });

      this.empService.getEmployees().subscribe(
        (res: any) => {
          console.log("response", res);
          const newObj = res.map((item: any) => {
            return {
              id: item._id,
              pid: item.pid,
              name: item.fullname,
              title: item.title,
              img: item.img,
            };
          });
          if (newObj) {
            chart.load(newObj);
          } else {
            chart.load(mockJson);
          }
        },
        (error: any) => {
          console.log(error);
          chart.load(mockJson);
        }
      );
    }
  }

  deleteEmployee(id: any) {
    this.empService.deleteEmployee(id).subscribe((res) => {
      console.log("response", res);
    });
  }

  addEmployee(payload: any) {
    this.empService.addEmployee(payload).subscribe((res) => {
      console.log("response", res);
      // this.router.navigate(['/']);
      this.router.navigateByUrl('/');
    });
  }

  editEmployee(payload: any) {
    const { id, fullname, name, pid, title, img } = payload;
    const body = { id, nodeId: id, fullname: name, pid, title, img };
    this.empService.updateEmployee(body).subscribe((res) => {
      console.log("response", res);
    });
  }
}

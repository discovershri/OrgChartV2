Orgchart application 

developed with node.js, express.js, angular 12

configure local mongodb intance 

update .env file with 

NODE_ENV=development
SERVER_PORT=4040
JWT_SECRET=0a6b944d-d2fb-46fc-a85e-0295c986cd9f
MONGO_HOST=mongodb://localhost:27017
MEAN_FRONTEND=angular

command to run on local

npm i
npm start

